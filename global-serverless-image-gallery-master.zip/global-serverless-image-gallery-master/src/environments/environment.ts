
export const environment = {
  production: false,
   region: 'us-east-2',
  apiUrl: 'https://apiendpoint/Stage',
  identityPoolId: 'cognito-identity-pool-id',
  fbId:'1234567888'
};

